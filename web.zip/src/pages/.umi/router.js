import React from 'react';
import {
  Router as DefaultRouter,
  Route,
  Switch,
  StaticRouter,
} from 'react-router-dom';
import dynamic from 'umi/dynamic';
import renderRoutes from 'umi/lib/renderRoutes';
import history from '@@/history';
import RendererWrapper0 from 'E:/虹信/培训资料/sei-demo-web-dev/src/pages/.umi/LocaleWrapper.jsx';
import { routerRedux, dynamic as _dvaDynamic } from 'dva';

const Router = routerRedux.ConnectedRouter;

const routes = [
  {
    path: '/user',
    redirect: '/user/login',
    exact: true,
    _title: 'sei-demo-web',
    _title_default: 'sei-demo-web',
  },
  {
    path: '/',
    redirect: '/dashboard',
    exact: true,
    _title: 'sei-demo-web',
    _title_default: 'sei-demo-web',
  },
  {
    path: '/user',
    component: __IS_BROWSER
      ? _dvaDynamic({
          component: () =>
            import(/* webpackChunkName: "layouts__LoginLayout" */ '../../layouts/LoginLayout'),
          LoadingComponent: require('E:/虹信/培训资料/sei-demo-web-dev/src/components/Loader')
            .default,
        })
      : require('../../layouts/LoginLayout').default,
    routes: [
      {
        path: '/user/login',
        component: __IS_BROWSER
          ? _dvaDynamic({
              component: () =>
                import(/* webpackChunkName: "p__Login" */ '../Login'),
              LoadingComponent: require('E:/虹信/培训资料/sei-demo-web-dev/src/components/Loader')
                .default,
            })
          : require('../Login').default,
        exact: true,
        _title: 'sei-demo-web',
        _title_default: 'sei-demo-web',
      },
      {
        component: () =>
          React.createElement(
            require('E:/虹信/培训资料/sei-demo-web-dev/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
              .default,
            { pagesPath: 'src/pages', hasRoutesInConfig: true },
          ),
        _title: 'sei-demo-web',
        _title_default: 'sei-demo-web',
      },
    ],
    _title: 'sei-demo-web',
    _title_default: 'sei-demo-web',
  },
  {
    path: '/',
    component: __IS_BROWSER
      ? _dvaDynamic({
          component: () =>
            import(/* webpackChunkName: "layouts__AuthLayout" */ '../../layouts/AuthLayout'),
          LoadingComponent: require('E:/虹信/培训资料/sei-demo-web-dev/src/components/Loader')
            .default,
        })
      : require('../../layouts/AuthLayout').default,
    routes: [
      {
        path: '/dashboard',
        component: __IS_BROWSER
          ? _dvaDynamic({
              component: () =>
                import(/* webpackChunkName: "p__Dashboard" */ '../Dashboard'),
              LoadingComponent: require('E:/虹信/培训资料/sei-demo-web-dev/src/components/Loader')
                .default,
            })
          : require('../Dashboard').default,
        exact: true,
        _title: 'sei-demo-web',
        _title_default: 'sei-demo-web',
      },
      {
        path: '/moduleName',
        name: 'moduleName',
        routes: [
          {
            path: '/moduleName/demo',
            component: __IS_BROWSER
              ? _dvaDynamic({
                  component: () =>
                    import(/* webpackChunkName: "layouts__AuthLayout" */ '../Demo'),
                  LoadingComponent: require('E:/虹信/培训资料/sei-demo-web-dev/src/components/Loader')
                    .default,
                })
              : require('../Demo').default,
            exact: true,
            _title: 'sei-demo-web',
            _title_default: 'sei-demo-web',
          },
          {
            component: () =>
              React.createElement(
                require('E:/虹信/培训资料/sei-demo-web-dev/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
                  .default,
                { pagesPath: 'src/pages', hasRoutesInConfig: true },
              ),
            _title: 'sei-demo-web',
            _title_default: 'sei-demo-web',
          },
        ],
        _title: 'sei-demo-web',
        _title_default: 'sei-demo-web',
      },
      {
        path: '/authData',
        name: '培训演示数据',
        routes: [
          {
            path: '/authData/index',
            component: __IS_BROWSER
              ? _dvaDynamic({
                  app: require('@tmp/dva').getApp(),
                  models: () => [
                    import(/* webpackChunkName: 'p__AuthData__model.js' */ 'E:/虹信/培训资料/sei-demo-web-dev/src/pages/AuthData/model.js').then(
                      m => {
                        return { namespace: 'model', ...m.default };
                      },
                    ),
                  ],
                  component: () =>
                    import(/* webpackChunkName: "layouts__AuthLayout" */ '../AuthData'),
                  LoadingComponent: require('E:/虹信/培训资料/sei-demo-web-dev/src/components/Loader')
                    .default,
                })
              : require('../AuthData').default,
            title: '培训演示数据',
            exact: true,
            Routes: [require('./TitleWrapper.jsx').default],
            _title: '培训演示数据',
            _title_default: 'sei-demo-web',
          },
          {
            component: () =>
              React.createElement(
                require('E:/虹信/培训资料/sei-demo-web-dev/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
                  .default,
                { pagesPath: 'src/pages', hasRoutesInConfig: true },
              ),
            _title: 'sei-demo-web',
            _title_default: 'sei-demo-web',
          },
        ],
        _title: 'sei-demo-web',
        _title_default: 'sei-demo-web',
      },
      {
        component: () =>
          React.createElement(
            require('E:/虹信/培训资料/sei-demo-web-dev/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
              .default,
            { pagesPath: 'src/pages', hasRoutesInConfig: true },
          ),
        _title: 'sei-demo-web',
        _title_default: 'sei-demo-web',
      },
    ],
    _title: 'sei-demo-web',
    _title_default: 'sei-demo-web',
  },
  {
    component: () =>
      React.createElement(
        require('E:/虹信/培训资料/sei-demo-web-dev/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
          .default,
        { pagesPath: 'src/pages', hasRoutesInConfig: true },
      ),
    _title: 'sei-demo-web',
    _title_default: 'sei-demo-web',
  },
];
window.g_routes = routes;
const plugins = require('umi/_runtimePlugin');
plugins.applyForEach('patchRoutes', { initialValue: routes });

export { routes };

export default class RouterWrapper extends React.Component {
  unListen() {}

  constructor(props) {
    super(props);

    // route change handler
    function routeChangeHandler(location, action) {
      plugins.applyForEach('onRouteChange', {
        initialValue: {
          routes,
          location,
          action,
        },
      });
    }
    this.unListen = history.listen(routeChangeHandler);
    // dva 中 history.listen 会初始执行一次
    // 这里排除掉 dva 的场景，可以避免 onRouteChange 在启用 dva 后的初始加载时被多执行一次
    const isDva =
      history.listen
        .toString()
        .indexOf('callback(history.location, history.action)') > -1;
    if (!isDva) {
      routeChangeHandler(history.location);
    }
  }

  componentWillUnmount() {
    this.unListen();
  }

  render() {
    const props = this.props || {};
    return (
      <RendererWrapper0>
        <Router history={history}>{renderRoutes(routes, props)}</Router>
      </RendererWrapper0>
    );
  }
}
