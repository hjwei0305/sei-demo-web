/*
* @Author: zp
* @Date:   2020-02-02 14:55:47
 * @Last Modified by: zp
 * @Last Modified time: 2020-04-24 17:17:44
*/
export default {
  'authData': 'authData'
}
