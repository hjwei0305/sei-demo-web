/*
* @Author: zp
* @Date:   2020-02-02 14:55:26
 * @Last Modified by: zp
 * @Last Modified time: 2020-04-24 17:17:40
*/
export default {
  'authData': 'authData'
}
