export default () => {
  // optimize chunks
  // config.output
  //   .filename('[name].[hash].js');
};
