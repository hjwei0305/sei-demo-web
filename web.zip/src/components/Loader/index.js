import { PageLoader } from 'suid';

export default PageLoader;
