import React from 'react';

const Demo = () => <div>Hello World</div>;

export default Demo;
